import pyfiglet
word = pyfiglet.figlet_format("qxresearch",font="alphabet")
print(word)

```
Output:
                                       h
                                       h
 qqq  x x rrr eee  ss eee  aa rrr  ccc hhh
q  q   x  r   e e  s  e e a a r   c    h  h
 qqq  x x r   ee  ss  ee  aaa r    ccc h  h
   q
   qq


```
