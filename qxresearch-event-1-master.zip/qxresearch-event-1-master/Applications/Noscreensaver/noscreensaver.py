import pyautogui

# A infinite loop
while 1>0:
    # makes the mouse sleep or wait for 40 seconds
    pyautogui.sleep(40)
    # clicks about in the corner of the screen like
    # on the co-ordinates of (50,400)
    pyautogui.click(50,400)