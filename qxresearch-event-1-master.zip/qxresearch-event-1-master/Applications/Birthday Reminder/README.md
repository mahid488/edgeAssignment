 <br />
<p align="center">
  <a href="https://www.youtube.com/channel/UCX7oe66V8zyFpAJyMfPL9VA">
    <img width="250px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/qxr/bb.gif" alt="Logo">
  </a>

  <h3 align="center">Birthday Reminder</h3>

  <p align="center">
    Python Application | 10 lines of code + Video Explanation 🧭
    <br>
    <br />
  </p>
</p>

You can create a normal birthday reminder program using `python`. You need to set the date and time of the birthday and reminder and you'll get an reminder of your or your friend's birthday notification. But I feel that this program is useless because you've to keep this code runnig... we can create a notification to make this code cooler and ready to public use. Well, develop and add features to this code mr. `Developer` `Researcher` 
 ```
What the program does? 

- User will select birthday
- User will select time of the reminder
- In that day | time program will wish her/him a happy birthday ❤️
``` 
### Requirements

* Python
* Python Libraries: `datetime`

### Contributing

Any kind of contributions to `qxresearch-event-1/birthday-reminder` are welcome. While creating an issue(for this project) use `Birthday-Reminder` Label.

1. [Fork](https://github.com/qxresearch/qxresearch-event-1/fork) the Project
2. Commit your Changes
3. Open a [Pull Request](https://github.com/qxresearch/qxresearch-event-1/pulls)

### Video Tutorial

* **YouTube :** [Birthday Reminder](https://youtu.be/qHloV2ZCo4s)

### Become Official Member @qxresearch

* Join Mozilla Group [@qxresearch](https://community.mozilla.org/en/groups/qx-research/)
* Join Telegram Group [@qxresearch](https://t.me/qxresearch)
* <a href = "mailto: rohitmandal814566@gmail.com">email</a> me your GitHub id (**subject**: GitHub id @qxresearch)


<h3 align="center"></h3>

  <p align="center">
    <br>
    <br/>
    <a href="https://youtu.be/qHloV2ZCo4s">View Demo</a>
    ·
    <a href="https://github.com/qxresearch/qxresearch-event-1/issues">Report Bug</a>
    ·
    <a href="https://github.com/qxresearch/qxresearch-event-1/issues">Request Feature</a>
    <br>
    <br />
  </p>
</p>
